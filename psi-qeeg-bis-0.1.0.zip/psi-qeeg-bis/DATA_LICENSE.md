# Included data: CC BY 4.0

The real EEG and monitor measurements in `examples/vitaldb_case1/recording.csv` are from the **VitalDB Open Dataset**, created by the VitalDB team at Seoul National University Hospital. They are distributed under [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/), separately from this repository's MIT software license.

Attribution: Lee HC, Park Y, Yoon SB, Yang SM, Park D, Jung CW. *VitalDB, a high-fidelity multi-parameter vital signs database in surgical patients*. Scientific Data 9, 279 (2022). [doi:10.1038/s41597-022-01411-5](https://doi.org/10.1038/s41597-022-01411-5).

Sources: [VitalDB data-use agreement](https://vitaldb.net/docs/?documentId=OpenDataset/Overview.md) and [PhysioNet VitalDB license](https://physionet.org/content/vitaldb/1.0.0/).

Changes: case 1 excerpted to seconds 332–452; compact waveform timestamps reconstructed from the original 128 Hz sample clock; sparse numeric tracks aligned by causal last observation with a five-second maximum age. Raw EEG amplitudes are retained. Identifiers are the source's public de-identified case identifier. No new psychiatric labels or diagnoses are added and no re-identification is attempted.

Retain this attribution, the license link and modification notice when sharing the included data or derived figures. Source-track identifiers and decompressed CSV checksums are in the example metadata.

`examples/paper_calculation` contains explicitly illustrative arithmetic inputs from the author's article, not measured patient EEG. Synthetic analytical test fixtures in `tests` are separately identified in their test names/docstrings.

